// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine.

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var horas: [Int] = [11, 13, 15, 17, 19, 20]
    
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var tabla: UITableView!
    
    var pelicula: Peliculas!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        poster.image = UIImage(named: pelicula.foto)
        nombre.text = pelicula.nombre
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return horas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! HorarioTableViewCell
        cell.hora.text = "\(horas[indexPath.row]):00"
        return cell
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let thirdView = segue.destination as! ThirdViewController
        let myIndexPath = tabla.indexPathForSelectedRow
        thirdView.hora = "\(horas[(myIndexPath?.row)!]):00"
        thirdView.pelicula = pelicula
        print(type(of: myIndexPath))
        
    }
    
    
    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
