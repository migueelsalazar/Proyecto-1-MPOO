// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine. 

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo


import UIKit

class ThirdViewController: UIViewController {
    
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var horario: UILabel!
    @IBOutlet weak var numbol: UILabel!
    @IBOutlet weak var slider: UISlider!
    
    var pelicula: Peliculas!
    var hora: String!

    override func viewDidLoad() {
        super.viewDidLoad()

        poster.image = UIImage(named: pelicula.foto)
        titulo.text = pelicula.nombre
        horario.text = hora
    }
    

    @IBAction func boletos(_ sender: UISlider) {
        numbol.text = String(Int(slider.value))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let fourthView = segue.destination as! FourthViewController
        fourthView.pelicula = pelicula
        fourthView.hora = hora
        fourthView.boletos = Int(slider.value)
        
        
    }
    
    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}
