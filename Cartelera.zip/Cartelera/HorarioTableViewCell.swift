// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine.

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo

import UIKit

class HorarioTableViewCell: UITableViewCell {
    @IBOutlet weak var hora: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    
    
    
}
