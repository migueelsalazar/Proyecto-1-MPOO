// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine.

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo


import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {
   
    @IBOutlet weak var coleccion: UICollectionView!
    
    var cine: [Peliculas] = [Peliculas(nombre:"El Bromas", foto: "el bromas", precio: 50, sub: 1), Peliculas(nombre: "Star Wars", foto: "star wars", precio: 50, sub: 2), Peliculas(nombre: "No Manches Frida 2", foto: "no_manches_frida_two", precio: 50, sub: 3),Peliculas(nombre:"Ad Astra", foto: "ad_astra_ver6_xlg", precio: 50, sub: 4)]
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cine.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cuadrito", for: indexPath) as! PelsCollectionViewCell
        
        cell.nombre.text = cine[indexPath.item].nombre
        cell.foto.image = UIImage(named: cine[indexPath.item].foto)
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let secondView = segue.destination as! SecondViewController
        
        let myIndexPath = coleccion.indexPathsForSelectedItems
        
        secondView.pelicula = cine[myIndexPath!.first!.item]
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
