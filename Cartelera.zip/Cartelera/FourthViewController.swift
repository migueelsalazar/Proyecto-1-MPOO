// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine.

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo


import UIKit

class FourthViewController: UIViewController {

    var pelicula: Peliculas!
    var hora: String!
    var boletos: Int!
    let sala = Int.random(in: 0...10)
   
    @IBOutlet weak var fotoFin: UIImageView!
    @IBOutlet weak var nombreF: UILabel!
    @IBOutlet weak var horarioF: UILabel!
    @IBOutlet weak var numbolF: UILabel!
    @IBOutlet weak var Imprimir_precio: UILabel!
   
    //------------------------------------
    
    @IBOutlet weak var infoSala: UILabel!
    
    @IBOutlet weak var Disp: UILabel!
    
    
    
    
    //---------------------------------------
    
    var tBromas :Int = 30
    var tFrida :Int = 30
    var tAstra :Int = 30
    var tStar :Int = 30

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fotoFin.image = UIImage(named: pelicula.foto)
        nombreF.text = pelicula.nombre
        horarioF.text = hora
        if boletos == 1 {
            numbolF.text = "\(String(boletos)) boleto"
        } else {
            numbolF.text = "\(String(boletos)) boletos"
        }
        
        var costo : Int = 0
        
        switch  boletos{
        case 1:
                    switch pelicula.sub {
                        case 1:
                            tBromas = tBromas - 1
                                if tBromas == 0 {
                                    Disp.text = "No hay boletos"
                                }
                                else {
                                    Disp.text = "Quedan \(tBromas) boletos "
                                }
                        case 2:
                            tStar = tStar - 1
                            if tStar == 0 {
                                Disp.text = "No hay boletos"
                            }
                            else {
                                Disp.text = "Quedan \(tStar) boletos "
                            }
                        case 3:
                            tFrida = tFrida - 1
                            if tFrida == 0 {
                                if tFrida == 0 {
                                    Disp.text = "No hay boletos"
                                }
                                else {
                                    Disp.text = "Quedan \(tFrida) boletos "
                                }
                            }
                        case 4:
                            tAstra = tAstra - 1
                            if tAstra == 0 {
                                if tAstra == 0 {
                                    Disp.text = "No hay boletos"
                                }
                                else {
                                    Disp.text = "Quedan \(tAstra) boletos "
                                }
                            }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 2:
                switch pelicula.sub {
                    case 1: //Bromas
                        tBromas = tBromas - 2
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas)boletos"
                    }
                    case 2:
                        tStar = tStar - 2
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar)boletos"
                    }
                    case 3:
                        tFrida = tFrida - 2
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida)boletos"
                    }
                    case 4:
                        tAstra = tAstra - 2
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra)boletos"
                    }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 3:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 3
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas)boletos"
                        }
                    case 2:
                        tStar = tStar - 3
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar)boletos"
                        }
                    case 3:
                        tFrida = tFrida - 3
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida)boletos"
                        }
                    case 4:
                        tAstra = tAstra - 3
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra)boletos"
                        }
                    default:
                            print("Movimiento no válido")
                        }
            costo = boletos*50
        case 4:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 4
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas) boletos"
                        }
                    case 2:
                        tStar = tStar - 4
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar) boletos"
                        }
                    case 3:
                        tFrida = tFrida - 4
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida) boletos"
                        }
                    case 4:
                        tAstra = tAstra - 4
                        
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra) boletos"
                        }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 5:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 5
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas) boletos"
                        }
                    case 2:
                        tStar = tStar - 5
                        
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar) boletos"
                        }
                    case 3:
                        tFrida = tFrida - 5
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida) boletos"
                        }
                        tAstra = tAstra - 5
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra) boletos"
                        }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 6:
                        switch pelicula.sub {
                        case 1:
                            tBromas = tBromas - 6
                            if tBromas == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tBromas) boletos"
                            }
                        case 2:
                            tStar = tStar - 6
                            if tStar == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tStar) boletos"
                            }
                        case 3:
                            tFrida = tFrida - 6
                            if tFrida == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tFrida) boletos"
                            }
                        case 4:
                            tAstra = tAstra - 6
                            if tAstra == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tAstra) boletos"
                            }
                        default:
                            print("Movimiento no válido")
                        }
                costo = boletos*50
            case 7:
                        switch pelicula.sub {
                        case 1:
                            tBromas = tBromas - 7
                            if tBromas == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tBromas) boletos"
                            }
                        case 2:
                            tStar = tStar - 7
                            if tStar == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tStar) boletos"
                            }
                        case 3:
                            tFrida = tFrida - 7
                            if tFrida == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tFrida) boletos"
                            }
                        case 4:
                            tAstra = tAstra - 7
                            if tAstra == 0 {
                                Disp.text = "No hay boletos"
                            }else{
                                Disp.text = "Quedan \(tAstra) boletos"
                            }
                        default:
                            print("Movimiento no válido")
                        }
            costo = boletos*50
        case 8:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 8
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas) boletos"
                        }
                    case 2:
                        tStar = tStar - 8
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar) boletos"
                        }
                    case 3:
                        tFrida = tFrida - 8
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida) boletos"
                        }
                    case 4:
                        tAstra = tAstra - 8
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra) boletos"
                        }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 9:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 9
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas) boletos"
                        }
                    case 2:
                        tStar = tStar - 9
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar) boletos"
                        }
                    case 3:
                        tFrida = tFrida - 9
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida) boletos"
                        }
                    case 4:
                        tAstra = tAstra - 9
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra) boletos"
                        }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        case 10:
                    switch pelicula.sub {
                    case 1:
                        tBromas = tBromas - 10
                        if tBromas == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tBromas) boletos"
                        }
                    case 2:
                        tStar = tStar - 10
                        if tStar == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tStar) boletos"
                        }
                    case 3:
                        tFrida = tFrida - 10
                        if tFrida == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tFrida) boletos"
                        }
                    case 4:
                        tAstra = tAstra - 10
                        if tAstra == 0 {
                            Disp.text = "No hay boletos"
                        }else{
                            Disp.text = "Quedan \(tAstra) boletos"
                        }
                    default:
                        print("Movimiento no válido")
                    }
            costo = boletos*50
        default:
            print("Movimiento no válido")
        }
        Imprimir_precio.text = "El costo es \(costo)"
        infoSala.text = "Sala: \(sala)"
        // Disponibilidad de boletos
    }
    @IBAction func inicio(_ sender: UIButton) {
        self.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
