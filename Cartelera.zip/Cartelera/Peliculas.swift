// Universidad Nacional Autónoma de México
// Facultad de Ingeniería
// División de Ingeniería Eléctrica
// Modelos de Programaciñon Orientada a Ojetos.

//          Proyecto 1: Cartelera de Cine.

//  Integrantes:
//      López Salazar Miguel Ángel
//      Rodríguez Ortiz Rodrigo


import UIKit


struct Peliculas {
    var nombre: String
    var foto: String
    var precio: Int
    var sub: Int 
}
